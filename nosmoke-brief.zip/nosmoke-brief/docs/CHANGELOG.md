# Changelog
Все заметные изменения в этом проекте.

## [0.2.0] - 2025-08-08
### Added
- Логирование входящих сообщений + ротация по дате
- Команда /stats (сводка за сегодня)

### Fixed
- Проблемы с MarkdownV2 в /about

## [0.1.0] - 2025-08-06
### Added
- Базовые команды: /start, /ping, /help, /echo, /quiet, /about
- Webhook через Caddy, Docker, автодеплой GitHub Actions
